﻿namespace ASSESSMENT_2_GROCERRY
{
    public class Grocerryitem
    {
        public int itemID { get; set; }

        public char name { get; set; }

        public int quantity{ get; set; }
        public int price { get; set; }
    }
}
