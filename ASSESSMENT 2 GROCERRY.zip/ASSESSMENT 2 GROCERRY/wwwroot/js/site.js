﻿
const groceryItems = [
    { id: 10011, name: "Avocado", qty: 3, price: 20.00 },
    { id: 10012, name: "Tomato", qty: 6, price: 5.00 },
    { id: 10013, name: "Orange", qty: 9, price: 15.50 },
    { id: 10014, name: "Mango", qty: 6, price: 25.00 },
    { id: 10015, name: "Guava", qty: 7, price: 5.00 }
];

const VAT_RATE = 0.16; // 16% VAT in Kenya

function generateReceipt() {
    let receiptBody = document.getElementById("receipt-body");
    let subtotal = 0;

    // Clear previous entries
    receiptBody.innerHTML = "";

    // Loop through grocery items and generate table rows
    groceryItems.forEach(item => {
        let total = item.qty * item.price;
        subtotal += total;

        let row = `
            <tr>
                <td>${item.id}</td>
                <td>${item.name}</td>
                <td>${item.qty}</td>
                <td>$${item.price.toFixed(2)}</td>
                <td>$${total.toFixed(2)}</td>
            </tr>
        `;
        receiptBody.innerHTML += row;
    });

    // Calculate tax and grand total
    let tax = subtotal * VAT_RATE;
    let grandTotal = subtotal + tax;

    // Update totals on the page
    document.getElementById("subtotal").innerText = `$${subtotal.toFixed(2)}`;
    document.getElementById("tax").innerText = `$${tax.toFixed(2)}`;
    document.getElementById("grand-total").innerText = `$${grandTotal.toFixed(2)}`;

    // Save receipt to file (simulating file output)
    saveToFile(groceryItems, subtotal, tax, grandTotal);
}

function saveToFile(items, subtotal, tax, grandTotal) {
    let receiptText = "Item ID | Name | Qty | Price | Total\n";
    receiptText += "----------------------------------------\n";

    items.forEach(item => {
        let total = item.qty * item.price;
        receiptText += `${item.id} | ${item.name} | ${item.qty} | $${item.price.toFixed(2)} | $${total.toFixed(2)}\n`;
    });

    receiptText += `\nSubtotal: $${subtotal.toFixed(2)}`;
    receiptText += `\nTax (16%): $${tax.toFixed(2)}`;
    receiptText += `\nGrand Total: $${grandTotal.toFixed(2)}`;

    // Create a downloadable file
    let blob = new Blob([receiptText], { type: "text/plain" });
    let link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "Receipt.txt";
    link.click();
}

